package com.programmingbooks.libraryapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.github.barteksc.pdfviewer.PDFView;

public class PdfViewerActivity extends AppCompatActivity {

    PDFView pdfView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        pdfView = findViewById(R.id.pdfView);

        // Get file name from intent
        String fileName = getIntent().getStringExtra("pdfFile");

        if (fileName != null) {
            // Load PDF from assets folder
            pdfView.fromAsset(fileName).load();
        }
    }
}
