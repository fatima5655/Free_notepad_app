package com.programmingbooks.libraryapp;

public class BookModel {
    private String title;
    private int imageResId;
    private String pdfFileName;

    public BookModel(String title, int imageResId, String pdfFileName) {
        this.title = title;
        this.imageResId = imageResId;
        this.pdfFileName = pdfFileName;
    }

    // Getter methods
    public String getTitle() {
        return title;
    }

    public int getImageResId() {
        return imageResId;
    }

    public String getPdfFileName() {
        return pdfFileName;
    }

    // Optional: Setter methods if you want to allow changes
    public void setTitle(String title) {
        this.title = title;
    }

    public void setImageResId(int imageResId) {
        this.imageResId = imageResId;
    }

    public void setPdfFileName(String pdfFileName) {
        this.pdfFileName = pdfFileName;
    }
}
