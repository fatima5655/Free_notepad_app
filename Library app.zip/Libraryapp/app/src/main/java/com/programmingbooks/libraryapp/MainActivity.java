package com.programmingbooks.libraryapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    List<BookModel> bookList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize book list
        bookList = new ArrayList<>();
        bookList.add(new BookModel("Learn C Programming", R.drawable.c_book, "c_book.pdf"));
        bookList.add(new BookModel("Java Basics", R.drawable.java_book, "java_book.pdf"));
        bookList.add(new BookModel("Python for Beginners", R.drawable.python_book, "python_book.pdf"));
        // Add more books here...

        // Set adapter
        BookAdapter adapter = new BookAdapter(this, bookList);
        recyclerView.setAdapter(adapter);
    }
}
